<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">  
    <meta name="viewport" content="width=device-width, height=device-height,  initial-scale=1.0, user-scalable=no;user-scalable=0;"/>
    <meta name="description" content="SHARMA LAB ADMIN">
    <meta name="keywords" content="SHARMA LAB">
    <meta name="author" content="pixelstrap">
    <link rel="icon" href="<?= SITE_URL;?>/assets/images/favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="<?= SITE_URL;?>/assets/images/favicon.png" type="image/x-icon">
    <title>ONLINE LAB REPORT</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/icofont.css">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/themify.css">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/flag-icon.css">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/feather-icon.css">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/sweetalert2.css">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/style.css">
    <link id="color" rel="stylesheet" href="<?= SITE_URL;?>/assets/css/color-7.css" media="screen">
    <link rel="stylesheet" type="text/css" href="<?= SITE_URL;?>/assets/css/responsive.css">

    <script src="<?= SITE_URL;?>/assets/js/jquery-3.5.1.min.js"></script>
    <script src="<?= SITE_URL;?>/assets/js/notify/bootstrap-notify.min.js"></script>
    <script src="<?= SITE_URL;?>/assets/js/notify/notify-script.js"></script>

  </head>
  <body class="dark-only1">
    <div class="loader-wrapper">
      <div class="theme-loader">    
        <div class="loader-p"></div>
      </div>
    </div>